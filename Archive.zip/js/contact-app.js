$(function() {
  $(".contact a.send").click(function() {
    $(".contact .submit").click();
  });
});
